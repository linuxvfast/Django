from django.shortcuts import render,HttpResponse

# Create your views here.
import requests

def req(request):
    response = requests.get('http://weatherapi.market.xiaomi.com/wtr-v2/weather?cityId=101121301')
    print(response.status_code)
    response.encoding = response.apparent_encoding
    return render(request,'req.html',{'res':response.text})
