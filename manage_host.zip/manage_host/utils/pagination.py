from django.utils.safestring import mark_safe


class Page:
    def __init__(self,current_page,data_count,per_page_count=10,default_page=7):
        self.current_page = current_page
        self.data_count = data_count
        self.per_page_count = per_page_count
        self.default_page = default_page

    @property
    def start(self):
        #分页中显示数据的起始位置
        return (self.current_page-1) * self.per_page_count

    @property
    def end(self):
        #分页中显示数据的结束位置
        return self.current_page * self.per_page_count

    @property
    def all_count(self):
        #统计总共的分页数
        count, y = divmod(self.data_count, self.per_page_count)
        if y:
            count += 1
        return count

    def page_str(self,base_url):
        '''
        定义分页数据和分页的显示
        :all_count:表示总共显示的页数
        :return:
        '''
        page_list = []
        if self.all_count <= self.default_page:
            start_index = 1
            end_index = self.all_count + 1
        else:
            if self.current_page <= (self.default_page + 1) / 2:
                start_index = 1
                end_index = self.default_page + 1
            else:
                start_index = self.current_page - (self.default_page - 1) / 2
                end_index = self.current_page + (self.default_page + 1) / 2
                if (self.current_page + (self.default_page - 1) / 2) > self.all_count:
                    end_index = self.all_count + 1
                    start_index = self.all_count - self.default_page - 1
        # 实现上一页自动跳转
        if self.current_page == 1:
            prev_page = '<a class="page" href="javascript:void(0)">上一页</a>'
        else:
            prev_page = '<a class="page" href="%s?p=%s">上一页</a>' % (base_url,self.current_page - 1)
        page_list.append(prev_page)

        for i in range(int(start_index), int(end_index)):#1,8
            if i == self.current_page:
                paging = '<a class="page active" href="%s?p=%s">%s</a>' % (base_url,i, i)
            else:
                paging = '<a class="page" href="%s?p=%s">%s</a>' % (base_url,i, i)
            page_list.append(paging)

        # 实现下一页自动跳转
        if self.current_page == self.all_count:
            next_page = '<a class="page" href="#">下一页</a>'
        else:
            next_page = '<a class="page" href="%s?p=%s">下一页</a>' % (base_url,self.current_page + 1)
        page_list.append(next_page)
        page_str = mark_safe(''.join(page_list))
        return page_str

if __name__ == '__main__':
    page_test = Page(1,500)
    print(page_test.page_str('/cmdb/user_list/'))