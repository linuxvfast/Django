from django.shortcuts import render

# Create your views here.
from django.shortcuts import HttpResponse
from cmdb import models
from django.shortcuts import redirect
import json
from django.utils.safestring import mark_safe
from utils import pagination

def add_info(request):
    '''
    添加测试数据
    :param request:
    :return:
    '''
    # models.Host.objects.create(nid=1,hostname='www.a.com',ip='192.168.1.123',port=22,module_id=1)
    # models.Host.objects.create(nid=2,hostname='www.b.com',ip='192.168.1.12',port=3389,module_id=2)
    # models.Application.objects.create(name='web')
    # models.Application.objects.create(name='后台')
    # models.Application.objects.create(name='db')
    # models.Application.objects.create(name='设计')
    # obj = models.Application.objects.filter(id=2).first()
    # obj.r.add(*[3,4,5,6])
    return HttpResponse('OK')

def business(request):
    '''
    获取busines表中的数据显示在模板文件中
    :param request:
    :return:
    '''
    v1 = models.Business.objects.all()  #对象
    print(v1)
    v2 = models.Business.objects.all().values('id','caption')   #字典
    v3 = models.Business.objects.all().values_list('id','caption')  #元组
    print(v2)
    print(v3)
    return render(request,'business.html',{'v1':v1,'v2':v2,'v3':v3})

def hosts(request):
    '''
    获取host表中的数据显示在模板文件中
    :param request:
    :return:
    '''
    if request.method == 'GET':
        busines_list = models.Business.objects.all()
        v1 = models.Host.objects.filter(nid__gt=0)
        # for row in v1:
        #     print(row.nid,row.hostname,row.ip,row.port,row.module_id,row.module.id,row.module.caption)
        #对象中取值时使用.进行取值
        v2 = models.Host.objects.filter(nid__gt=0).values('nid','hostname','ip','port','module_id','module__id','module__caption')
        # print(v2)
        # for row in v2:
        #     print(row['nid'],row['hostname'],row['ip'],row['port'],row['module_id'],row['module__id'],row['module__caption'])
        
        v3 = models.Host.objects.filter(nid__gt=0).values_list('nid','hostname','ip','port','module_id','module__id','module__caption')
        # print(v3)
        # for row in v3:
        #     print(row[0],row[1],row[2],row[3],row[4],row[5],row[6])
        return render(request,'host.html',{'v1':v1,'v2':v2,'v3':v3,'busines_list':busines_list})
    elif request.method == 'POST':
        host_name = request.POST.get('hostname',None)
        host_ip = request.POST.get('ip',None)
        host_port = request.POST.get('port',None)
        businesid = request.POST.get('module_id',None)
        # print(host_name,host_ip,host_port,businesid)
        models.Host.objects.create(hostname=host_name,ip=host_ip,port=host_port,module_id=businesid)
        return redirect('/cmdb/host')

def test_ajax(request):
    '''host表添加功能'''
    # print(request.method,request.GET.get('hostname',None),request.GET.get('ip',None),sep='\t')
    ret = {'status': True, 'error': None, 'data': None}
    try:
        host_name = request.POST.get('hostname', None)
        host_ip = request.POST.get('ip', None)
        host_port = request.POST.get('port', None)
        businesid = request.POST.get('module_id', None)
        if host_name and len(host_name) > 5:
            models.Host.objects.create(hostname=host_name,
                                       ip=host_ip,
                                       port=host_port,
                                       module_id=businesid)
            return HttpResponse('接收成功')
        else:
            ret['status'] = False
            ret['error'] = "主机名太短了"
    except Exception as e:
        ret['status'] = False
        ret['error'] = '请求错误'
    return HttpResponse(json.dumps(ret))

def edit_ajax(request):
    '''host编辑功能'''
    ret = {'status': True, 'error': None, 'data': None}
    try:
        host_name = request.POST.get('hostname', None)
        host_ip = request.POST.get('ip', None)
        host_port = request.POST.get('port', None)
        businesid = request.POST.get('module_id', None)
        nid = request.POST.get('nid', None)
        # print(nid,businesid,host_port,host_ip,host_name)
        if host_name and len(host_name) > 5:
            models.Host.objects.filter(nid=nid).update(
                hostname=host_name,
                ip=host_ip,
                port=host_port,
                module_id=businesid)
        else:
            ret['status'] = False
            ret['error'] = "主机名太短了"
    except Exception as e:
        ret['status'] = False
        ret['error'] = '请求错误'
    return HttpResponse(json.dumps(ret))

def add_more_to_more(request):
    print(type(request))
    from django.core.handlers.wsgi import WSGIRequest
    print(request.environ)
    if request.method == 'GET':
        del_nid = request.GET.get('del_nid',None)
        app_list = models.Application.objects.all()
        host_list = models.Host.objects.all()
        print(del_nid)
        return render(request,'app.html',{'app_list':app_list,'host_list':host_list})
    elif request.method == 'POST':
        app_name = request.POST.get('app_name',None)
        host_list = request.POST.getlist('host_list',None)
        print(app_name,host_list)
        obj = models.Application.objects.create(name=app_name)
        obj.r.add(*host_list)
        return redirect('/cmdb/add_more_to_more')

# def dpl(request):
#     return render(request,'tpl.html')

#自定义分页


LIST = []
for i in range(500):
    LIST.append(i)
def user_list(request):
    current_page = request.GET.get('p',None)
    current_page = int(current_page)
    # print('current_page',current_page)
    # per_page_count = 10
    # start_pos = (current_page - 1) * 10
    # end_pos = current_page * 10
    # data = LIST[start_pos:end_pos]
    page_obj =pagination.Page(current_page,len(LIST))
    # print('start',page_obj.start())
    # print('end',page_obj.end())
    data = LIST[page_obj.start:page_obj.end]

    # page_str = '''
    #     <a class="page" href="/cmdb/user_list/?p=1">1</a>
    #     <a class="page" href="/cmdb/user_list/?p=2">2</a>
    #     <a class="page" href="/cmdb/user_list/?p=3">3</a>
    # '''
    # page_str = mark_safe(page_str)

    #对于上面页码的优化
    # all_count = len(LIST)
    #获取商和余数,count表示页数
    # count,y = divmod(all_count,per_page_count)
    # if y:
    #     count += 1
    # page_list = []
    # for i in range(1,count+1):
    #     if i == current_page:
    #         paging = '<a class="page active" href="/cmdb/user_list/?p=%s">%s</a>'%(i,i)
    #     else:
    #         paging = '<a class="page" href="/cmdb/user_list/?p=%s">%s</a>'%(i,i)
    #     page_list.append(paging)

    '''约束显示的页码，每页显示10行数据
        页数少于或多于指定的11个页码时，只显示有数据的页码
    '''
    # default_page = 7 #显示的页码数
    # start_index = current_page - (default_page-1)/2
    # end_index = current_page + (default_page+1)/2
    # if count <= default_page:
    #     start_index = 1
    #     end_index = count + 1
    # else:
    #     if current_page <= (default_page+1)/2:
    #         start_index = 1
    #         end_index = default_page + 1
    #     else:
    #         start_index = current_page - (default_page-1)/2
    #         end_index = current_page + (default_page+1)/2
    #         if (current_page + (default_page-1)/2) > count:
    #             end_index = count + 1
    #             start_index = count - default_page - 1
    # #实现上一页自动跳转
    # if current_page == 1:
    #     prev_page = '<a class="page" href="javascript:void(0)">上一页</a>'
    # else:
    #     prev_page = '<a class="page" href="/cmdb/user_list/?p=%s">上一页</a>'%(current_page-1)
    # page_list.append(prev_page)
    # for i in range(int(start_index),int(end_index)):
    #     if i == current_page:
    #         paging = '<a class="page active" href="/cmdb/user_list/?p=%s">%s</a>'%(i,i)
    #     else:
    #         paging = '<a class="page" href="/cmdb/user_list/?p=%s">%s</a>'%(i,i)
    #     page_list.append(paging)
    # #实现下一页自动跳转
    # if current_page == count:
    #     next_page = '<a class="page" href="#">下一页</a>'
    # else:
    #     next_page = '<a class="page" href="/cmdb/user_list/?p=%s">下一页</a>'%(current_page+1)
    # page_list.append(next_page)

    #添加选页跳转
    # jump = '''
    #     <!--添加跳转功能-->
    #         <input type="text" id="page_code"/>
    #         <button onclick="jumpTo(this,'{{ request.path_info }}?p=');" id="il1">GO</button>
    #     < script >
    #         < !--js实现button功能的跳转 -->
    #         function
    #         jumpTo(that, base_url)
    #         {
    #             var
    #         jump_page = that.previousElementSibling.value;
    #         location.href = base_url + jump_page;
    #         }
    #     < / script >
    # '''
    # page_list.append(jump)
    # page_str = mark_safe(''.join(page_list))
    page_str = page_obj.page_str('/cmdb/user_list/')
    # print(data)
    return render(request,'user_list.html',{'li':data,'page_str':page_str})