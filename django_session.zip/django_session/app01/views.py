from django.shortcuts import render
from django.shortcuts import redirect
from django.shortcuts import HttpResponse
# Create your views here.

#session原理
#服务器端会保存session生成的键值对，客户端保存session的sessionid，
# 通过判断session的属性是否登录成功，如果登录成功显示记录session的信息，
# 如果不成功不显示session的信息
def login(request):
    ret = {'data':None,'status':True,'errors':None}
    #获取请求头中csrf的名字
    # from django.conf import settings
    # print(settings.CSRF_HEADER_NAME) #HTTP_X_CSRFTOKEN

    if request.method == 'GET':
        return render(request,'login.html')
    elif request.method == 'POST':
        user = request.POST.get('user',None)
        pwd = request.POST.get('pwd',None)
        if user == 'root' and pwd == 'root':
            #生成随机字符串
            #写到用户浏览器cookie
            #保存到session中
            #在随机字符串对应的字典中设置相关的内容
            request.session['username'] = user
            request.session['is_login'] = True
            if request.POST.get('rmb',None) == '1':
                request.session.set_expiry(10) #设置session信息登录之后10秒钟过期(默认取第一次刷新之后的间隔时间)
                #request.session.set_expiry(10)结合settings文件中SESSION_SAVE_EVERY_REQUEST = True,以最后一次刷新的间隔时间计算
            return redirect('/index')
        else:
            error_msg = '账号或密码错误'
            return render(request,'login.html',{'error_msg':error_msg})

def index(request):
    if request.session.get('is_login',None):
        return render(request,'index.html')
    else:
        return HttpResponse('not login success')

def logout(request):
    request.session.clear()
    return redirect('/login')
